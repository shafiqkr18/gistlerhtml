<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gistler</title>

<meta name="description" content="">
<meta name="author" content="">
<!-- Le styles -->
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
<link href="assets/css/pricing.css" rel="stylesheet">
<!-- !important THIS STYLE CSS ON BOTTOM OF STYLEs LIST-->
<link href="assets/css/style.css" rel="stylesheet">
<!-- !important THIS STYLE CSS ON BOTTOM OF STYLEs LIST-->
<link href="assets/css/font-awesome.min.css" rel="stylesheet"> 
<link href="assets/css/prettyPhoto.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
<link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css'>
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!-- Le fav and touch icons -->
<link rel="shortcut icon" href="assets/ico/favicon.ico">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
 
	<link rel="stylesheet"  href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/star-rating.css" media="all" rel="stylesheet" type="text/css"/>
   <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  
  
   
</head>
<body data-spy="scroll" data-target=".scroller-spy" data-twttr-rendered="true">

<!--START MAIN-WRAPPER--> 
<div class="main-wrapper">
<!--START MAIN-WRAPPER--> 

<!-- TOP SECTION-->
<section class="section-2 mainnav" id="header-section">

 <!-- ################-->
 <!-- START TOP MENU -->
 <!-- ################-->
 <?php
  include('header3.php');
  ?>
	
  
  <div class="bg-wraper parallax-point-event">
	<br/>
	<div class="container">
		<div class="row-fluid" >
		<!-- FEATURE ITEM-->
		<script>
		$(document).scroll(function() {
			if($(this).scrollTop() > 240){
				 $("#fixedscroll").addClass("bottomfixed");
			}
			else{
				$("#fixedscroll").removeClass("bottomfixed");
			}
			
		});
		</script>

			<?php
			include('list-sidebar.php');
			?>
			<div class="row-fluid" >
				<div class="span12 advicedv">
					<div class="clear10"></div>
					<h2>Advice and guidelines</h2>
					<p>All information, laws, forms, calculators and procedures related to buy, sale and rentals in one place</p>
					<div class="clear10"></div>
					<div class="row">
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice1.png"><br/>
								<span>Buyer<br/>Checklist</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice2.png"><br/>
								<span>Seller<br/>Checklist</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice3.png"><br/>
								<span>Mortgage's<br/>Checklist</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice4.png"><br/>
								<span>Sale Transaction<br/>Fees & Charges</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice5.png"><br/>
								<span>Mortgage<br/>Calculator</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice6.png"><br/>
								<span>RERA<br/>Sale Forms</span>
								</a>
							</div>
						</div>
					</div>
					
					<div class="clear10"></div>
					
					<div class="row">	
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice7.png"><br/>
								<span>Registration<br/>Trustees</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice8.png"><br/>
								<span>RERA Sale Property<br/>Registration</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice9.png"><br/>
								<span>RERA Service<br/>Charge Index - Sale</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice10.png"><br/>
								<span>RERA Sale<br/>Property Laws</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice11.png"><br/>
								<span>Home<br/>Inspection</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice12.png"><br/>
								<span>Seller<br/>Tips</span>
								</a>
							</div>
						</div>
					
					</div>
					<div class="clear10"></div>
					<div class="row">
					
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice13.png"><br/>
								<span>MAKANI<br/>Dubai</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice14.png"><br/>
								<span>Tenant<br/>Checklist</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice15.png"><br/>
								<span>Landloard<br/>Checklist</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice16.png"><br/>
								<span>RERA<br/>Rental Index</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice17.png"><br/>
								<span>RERA Rental<br/>Increase Calculator</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice18.png"><br/>
								<span>RERA Service<br/>Charge Index - Rental</span>
								</a>
							</div>
						</div>
					
					</div>
					<div class="clear10"></div>
					<div class="row">
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice19.png"><br/>
								<span>RERA<br/>Rental Committee</span>
								</a>
							</div>
						</div>
						
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice20.png"><br/>
								<span>RERA Rental<br/>Property Laws</span>
								</a>
							</div>
						</div>
					
						<div class="span2">
							<div class="advicebox">
								<a href="advice_content.php">
								<img src="images/advice22.png"><br/>
								<span>Rental<br/>FAQs</span>
								</a>
							</div>
						</div>
					
					</div>
					<div class="clear"></div>
					
					
				</div>
				
			</div>
			
			
			
				
		
		<!-- FEATURE ITEM-->
		
		<!-- FEATURE ITEM-->
		</div><!--/ ROW-FLUID-->
		
	
	
	
	</div><!--/CONTAINER-->
</div><!-- / BG WRAPER-->
  
  
			<!-- END HEADER headertop NAV -->


			
</section><!--/ TOP SECTION-->

 

<!-- /SERVICE SECTION-->			

	
	<!-- /FEATURE section-->
	
	<!-- /SLOGAN section-->
	
	

<!-- /TEAM SECTION-->			




  

<!-- ###################### FOOTER #######################
    ================================================== -->
<?php
include('footer.php');
?>

<!-- END: FOOTER -->
</div>
<!-- END: MAIN-WRAPPER-->
<!-- Le javascript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

 
<script src="assets/js/google-code-prettify/prettify.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-transition.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-alert.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-modal.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-dropdown.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-scrollspy.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-tab.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-tooltip.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-popover.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-button.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-collapse.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-carousel.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-typeahead.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-affix.js" type="text/javascript"></script> 
<script src="assets/js/application.js" type="text/javascript"></script> 

<script src="assets/js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="assets/js/tweetable.jquery.js" type="text/javascript"></script>
<script src="assets/js/jquery.timeago.js" type="text/javascript"></script>

<script src="assets/js/jquery.fitvids.min.js" type="text/javascript"></script>

<!-- PARALLAX PLUGIN -->
<script type="text/javascript" src="assets/js/jquery.localscroll-1.2.7-min.js"></script>
<script type="text/javascript" src="assets/js/jquery.inview.js"></script>
<script type="text/javascript" src="assets/js/jquery.scrollTo-1.4.2-min.js"></script>
<script type="text/javascript" src="assets/js/jquery.parallax-1.1.3.js"></script>
<!-- PARALLAX PLUGIN -->

<!-- gMap PLUGIN -->
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="assets/js/jquery.gmap.js"></script>
<!-- gMap PLUGIN -->
<script src="assets/js/custom.js" type="text/javascript"></script>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#nav').localScroll(1000);
	jQuery('#nav2').localScroll(1000);
	jQuery('#nav6').localScroll(1000);
	jQuery('#nav3').localScroll(1000);
	jQuery('#nav4').localScroll(1000);
	jQuery('#nav5').localScroll(1000);
	
	//.parallax(xPosition, speedFactor, outerHeight) options:
	//xPosition - Horizontal position of the element
	//inertia - speed to move relative to vertical scroll. Example: 0.1 is one tenth the speed of scrolling, 2 is twice the speed of scrolling
	//outerHeight (true/false) - Whether or not jQuery should use it's outerHeight option to determine when a section is in the viewport
	jQuery('#header-section').parallax("50%", 0.1);
	jQuery('#features-section').parallax("50%", 0.1);
	jQuery('#slogan-section-2').parallax("50%", 0.1);
	jQuery('#team-section').parallax("50%", 0.1);
	jQuery('.bg').parallax("50%", 0.3);
	jQuery('#portfolio-section').parallax("50%", 0.3);
	jQuery('#price-section').parallax("50%", 0.3);
	jQuery('#contact-section').parallax("50%", 0.1);
	jQuery('#slogan-section-1').parallax("50%", 0.3);
	
})
</script>
<script>
jQuery('#features-section .parallax-point-event').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.effect-box-1').addClass("active");
			jQuery('.effect-box-2').addClass("active");
			jQuery('.effect-box-3').addClass("active");
			jQuery('.effect-box-4').addClass("active");
			
        }else{
            jQuery('.effect-box-1').removeClass("active");
			jQuery('.effect-box-2').removeClass("active");
			jQuery('.effect-box-3').removeClass("active");
			jQuery('.effect-box-4').removeClass("active");
		
			//jQuery('.effect-box').unbind('inview');
        }
    });
</script>

<script>
jQuery('#slogan-section-1').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.large-slogan').addClass("active");
		 }else{
            jQuery('.large-slogan').removeClass("active"); 	
        }
    });
</script>
<script>
jQuery('#slogan-section-2 .parallax-point-event').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.browser-shot-1').addClass("active");
			jQuery('.browser-shot-2').addClass("active");
			jQuery('.browser-shot-3').addClass("active");
			
        }else{
            jQuery('.browser-shot-1').removeClass("active"); 
			jQuery('.browser-shot-2').removeClass("active");
			jQuery('.browser-shot-3').removeClass("active");
			
        }
    });
</script>

<script>
jQuery('#slogan-section-3').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.goprice').addClass("active");
		}else{
            jQuery('.goprice').removeClass("active"); 	
        }
    });
</script>

<script>
jQuery('#header-section').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.gobottom').addClass("active"); 
			jQuery('.hero-unit h1 span').addClass("active");
			
        }else{
            jQuery('.gobottom').removeClass("active");  
			jQuery('.hero-unit h1 span').removeClass("active"); 
			
			
        }
    });
</script>


<script>
		var hero = jQuery('#header-section .hero-unit');
		jQuery(window).scroll(function () {
				if (jQuery(this).scrollTop() > 550) {
					hero.addClass("hide");	
				} else {
					hero.removeClass("hide");	
				}
			});
		</script>
		
	<script>
		var navbar = jQuery('#navbartop');
		var navbartop = jQuery('#topnavbar');
			/*sjQuery(window).scroll(function () {
				if (jQuery(this).scrollTop() > 640) {
				
					navbar.addClass("navbar-scroll");
					navbartop.removeClass("navbar-static-top");
					navbartop.addClass("navbar-fixed-top");
					
				} else {
					navbar.removeClass("navbar-scroll");
					navbartop.removeClass("navbar-fixed-top");
					navbartop.addClass("navbar-static-top");
				}
			});*/
			
			
			$(document).scroll(function() {
				if($(this).scrollTop() > 200){
					navbar.addClass("navbar-scroll");
					navbartop.removeClass("navbar-static-top");
					navbartop.addClass("navbar-fixed-top");
				}
				else{
					navbar.addClass("navbar-scroll");
					navbartop.removeClass("navbar-static-top");
					navbartop.addClass("navbar-fixed-top");
				}
				
			});
		</script>
		
		<script>
        // Basic FitVids Test
			$(".container").fitVids();  
		</script>
		
		<script type="text/javascript">
		
				jQuery(document).ready(function(){
				jQuery('#map').gMap({ address: 'Folsom Ave, San Francisco, CA',
							   panControl: true,
						   zoomControl: true,
							   zoomControlOptions: {
					style: google.maps.ZoomControlStyle.SMALL
							   },
						   mapTypeControl: true,
						   scaleControl: true,
						   streetViewControl: false,
						   overviewMapControl: true,
							   scrollwheel: true,
							   icon: {
						image: "http://www.google.com/mapfiles/marker.png",
						shadow: "http://www.google.com/mapfiles/shadow50.png",
						iconsize: [20, 34],
						shadowsize: [37, 34],
						iconanchor: [9, 34],
						shadowanchor: [19, 34]
					},
						zoom:15,
							   markers: [
							{ 'address' : 'Folsom Ave, San Francisco, CA'}
						]
							   
							   
							   }); 
				});
</script>

<script type="text/javascript">
		jQuery(function(){
			jQuery('#tweets').tweetable({
				username: 'wrapbootstrap', 
				time: true,
				rotate: false,
				speed: 4000, 
				limit: 1,
				replies: false,
				position: 'append',
				failed: "Sorry, twitter is currently unavailable for this user.",
				html5: true,
				onComplete:function(jQueryul){
					jQuery('time').timeago();
				}
			});
		});
		</script>
		<script>
			jQuery('.carousel').carousel()
		</script>
</body>
</html>