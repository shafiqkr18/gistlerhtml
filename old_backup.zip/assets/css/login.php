<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gistler</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<!-- Le styles -->
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
<link href="assets/css/pricing.css" rel="stylesheet">
<!-- !important THIS STYLE CSS ON BOTTOM OF STYLEs LIST-->
<link href="assets/css/style.css" rel="stylesheet">
<!-- !important THIS STYLE CSS ON BOTTOM OF STYLEs LIST-->
<link href="assets/css/font-awesome.min.css" rel="stylesheet"> 
<link href="assets/css/prettyPhoto.css" rel="stylesheet" type="text/css" />
<link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!-- Le fav and touch icons -->
<link rel="shortcut icon" href="assets/ico/favicon.ico">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
</head>
<body data-spy="scroll" data-target=".scroller-spy" data-twttr-rendered="true">

<!--START MAIN-WRAPPER--> 
<div class="main-wrapper">
<!--START MAIN-WRAPPER--> 

<!-- TOP SECTION-->
<section class="headertop needhead" id="header-section">

 <!-- ################-->
 <!-- START TOP MENU -->
 <!-- ################-->
  <?php
  include('header1.php');
  ?>
			<!-- END HEADER headertop NAV -->

			
<!-- HEADER MARKETING SLOGAN-->
<header class="container">
	<div class="row-fluid">
		<div class="">
			<div class="hero-unit text-center">
				<!--LOGO-->
				<div class="logo">
					<h3>WELCOME TO</h3>
					<a href="#" title="Scroll&amp;Strap">
						<img src="images/Logo.png" alt="logo"/>
					</a>
				</div>
				<!--/ LOGO-->
				
					<div class="inner-wrap-hero">
					
						<div class="searchbox">
							
							<div class="form-body">
								<div class="span12">
									
									<div class="tabs">
										
									   <div class="tab logintab">
										   <input type="radio" id="tab-1" name="tab-group-1" checked>
										   <label for="tab-1">SIGN IN </label>
										   <div class="clear"></div>
										   <div class="content loginform">
											   <input type="text" name="name" class="txtform" placeholder="Enter your email or username">
											    <input type="password" name="password" class="txtform" placeholder="Enter your password">
												<div class="clear10"></div>
												
												<div class="halfdv rememberdv">
													<input type="checkbox" class="remember" name="remember"> Remember Me<br/>
													<a href="#">Don't know your password?</a>
												</div>
												
												<div class="halfdv">
													<input type="submit" class="btn-login" value="SIGN IN">
												</div>
												<div class="clear"></div>
												<div class="clear10"></div>
												<div class="socialdv">
													<h4><span><img src="images/social-media-line.png"></span></h4>
													<a href="#" target="_blank"><img src="images/social-facebook.png"></a>
													<a href="#" target="_blank"><img src="images/social-twitter.png"></a>
													<a href="#" target="_blank"><img src="images/social-linkedin.png"></a>
													<a href="#" target="_blank"><img src="images/social-googleplus.png"></a>
												</div>
										   </div>
											<div class="clear"></div>
									   </div>
										
									   <div class="tab logintab">
										   <input type="radio" id="tab-2" name="tab-group-1">
										   <label for="tab-2">NEW ACCOUNT</label>
										   
										   <div class="content loginform2">
											   <input type="text" name="name" class="txtform2" placeholder="Username">
											    
												
												<div class="clear"></div>
												<div class="halfdv rememberdv">
													<input type="password" name="password" class="txtform" placeholder="Enter your email">
													<input type="password" name="password" class="txtform" placeholder="Enter your password">
												
													<input type="checkbox" class="remember" name="remember"> I am a licensed professional<br/>
													By clicking submit, you agree to GISTLER's <a href="#">Terms of Use</a>
												</div>
												
												<div class="halfdv rightdv">
													<input type="password" name="password" class="txtform" placeholder="Re - Enter your email">
													<input type="password" name="password" class="txtform" placeholder="Re - Enter your password">
													<input type="submit" class="btn-login" value="SUBMIT">
												</div>
												<div class="clear"></div>
												<div class="clear10"></div>
												<div class="socialdv">
													<h4><span>__________</span>OR SIGN IN WITH YOUR SOCIAL MEDIA ACCOUNT<span>__________</span></h4>
													<a href="#" target="_blank"><img src="images/social-facebook.png"></a>
													<a href="#" target="_blank"><img src="images/social-twitter.png"></a>
													<a href="#" target="_blank"><img src="images/social-linkedin.png"></a>
													<a href="#" target="_blank"><img src="images/social-googleplus.png"></a>
												</div>
										   </div> 
										   <div class="clear"></div>
									   </div>
										<div class="clear"></div>
										
									</div>
									
									<div class="clear10"></div>
									
									
									
								</div>
								
								
								<div class="clear clear10"></div>
								
								 
								
								
								<div class="clear"></div>
								<br/><br/><br/>
							</div>
						</div>
						
					</div>
				<!--<hr class="half">-->
			
			
			</div>	
		</div><!-- / HERO UNIT-->
	</div><!-- / HERO WRAP-->
</header><!-- / HEADER MARKETING SLOGAN container-->
			
</section><!--/ TOP SECTION-->




	<!-- /FEATURE section-->
	
	
<!-- /TEAM SECTION-->			




  

<!-- ###################### FOOTER #######################
    ================================================== -->
<?php
  include('footer.php');
  ?>

<!-- END: FOOTER -->
</div>
<!-- END: MAIN-WRAPPER-->
<!-- Le javascript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

<script src="assets/js/jquery.js" type="text/javascript"></script> 
<script src="assets/js/google-code-prettify/prettify.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-transition.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-alert.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-modal.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-dropdown.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-scrollspy.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-tab.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-tooltip.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-popover.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-button.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-collapse.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-carousel.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-typeahead.js" type="text/javascript"></script> 
<script src="assets/js/bootstrap-affix.js" type="text/javascript"></script> 
<script src="assets/js/application.js" type="text/javascript"></script> 

<script src="assets/js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="assets/js/tweetable.jquery.js" type="text/javascript"></script>
<script src="assets/js/jquery.timeago.js" type="text/javascript"></script>

<script src="assets/js/jquery.fitvids.min.js" type="text/javascript"></script>

<!-- PARALLAX PLUGIN -->
<script type="text/javascript" src="assets/js/jquery.localscroll-1.2.7-min.js"></script>
<script type="text/javascript" src="assets/js/jquery.inview.js"></script>
<script type="text/javascript" src="assets/js/jquery.scrollTo-1.4.2-min.js"></script>
<script type="text/javascript" src="assets/js/jquery.parallax-1.1.3.js"></script>
<!-- PARALLAX PLUGIN -->

<!-- gMap PLUGIN -->
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="assets/js/jquery.gmap.js"></script>
<!-- gMap PLUGIN -->
<script src="assets/js/custom.js" type="text/javascript"></script>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#nav').localScroll(1000);
	jQuery('#nav2').localScroll(1000);
	jQuery('#nav6').localScroll(1000);
	jQuery('#nav3').localScroll(1000);
	jQuery('#nav4').localScroll(1000);
	jQuery('#nav5').localScroll(1000);
	
	//.parallax(xPosition, speedFactor, outerHeight) options:
	//xPosition - Horizontal position of the element
	//inertia - speed to move relative to vertical scroll. Example: 0.1 is one tenth the speed of scrolling, 2 is twice the speed of scrolling
	//outerHeight (true/false) - Whether or not jQuery should use it's outerHeight option to determine when a section is in the viewport
	jQuery('#header-section').parallax("100%", 0.1);
	jQuery('#features-section').parallax("50%", 0.1);
	jQuery('#slogan-section-2').parallax("50%", 0.1);
	jQuery('#team-section').parallax("50%", 0.1);
	jQuery('.bg').parallax("50%", 0.3);
	jQuery('#portfolio-section').parallax("50%", 0.3);
	jQuery('#price-section').parallax("50%", 0.3);
	jQuery('#contact-section').parallax("50%", 0.1);
	jQuery('#slogan-section-1').parallax("50%", 0.3);
	
})
</script>
<script>
jQuery('#features-section .parallax-point-event').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.effect-box-1').addClass("active");
			jQuery('.effect-box-2').addClass("active");
			jQuery('.effect-box-3').addClass("active");
			jQuery('.effect-box-4').addClass("active");
			
        }else{
            jQuery('.effect-box-1').removeClass("active");
			jQuery('.effect-box-2').removeClass("active");
			jQuery('.effect-box-3').removeClass("active");
			jQuery('.effect-box-4').removeClass("active");
		
			//jQuery('.effect-box').unbind('inview');
        }
    });
</script>

<script>
jQuery('#slogan-section-1').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.large-slogan').addClass("active");
		 }else{
            jQuery('.large-slogan').removeClass("active"); 	
        }
    });
</script>
<script>
jQuery('#slogan-section-2 .parallax-point-event').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.browser-shot-1').addClass("active");
			jQuery('.browser-shot-2').addClass("active");
			jQuery('.browser-shot-3').addClass("active");
			
        }else{
            jQuery('.browser-shot-1').removeClass("active"); 
			jQuery('.browser-shot-2').removeClass("active");
			jQuery('.browser-shot-3').removeClass("active");
			
        }
    });
</script>

<script>
jQuery('#slogan-section-3').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.goprice').addClass("active");
		}else{
            jQuery('.goprice').removeClass("active"); 	
        }
    });
</script>

<script>
jQuery('#header-section').bind('inview', function (event, visible) {
        if (visible == true) {
            jQuery('.gobottom').addClass("active"); 
			jQuery('.hero-unit h1 span').addClass("active");
			
        }else{
            jQuery('.gobottom').removeClass("active");  
			jQuery('.hero-unit h1 span').removeClass("active"); 
			
			
        }
    });
</script>


<script>
		var hero = jQuery('#header-section .hero-unit');
		jQuery(window).scroll(function () {
				if (jQuery(this).scrollTop() > 550) {
					hero.addClass("hide");	
				} else {
					hero.removeClass("hide");	
				}
			});
		</script>
		
	<script>
		var navbar = jQuery('#navbartop');
		var navbartop = jQuery('#topnavbar');
			jQuery(window).scroll(function () {
				if (jQuery(this).scrollTop() > 640) {
				
					navbar.addClass("navbar-scroll");
					navbartop.removeClass("navbar-static-top");
					navbartop.addClass("navbar-fixed-top");
					
				} else {
					navbar.removeClass("navbar-scroll");
					navbartop.removeClass("navbar-fixed-top");
					navbartop.addClass("navbar-static-top");
				}
			});
		</script>
		
		<script>
        // Basic FitVids Test
			$(".container").fitVids();  
		</script>
		
		<script type="text/javascript">
		
				jQuery(document).ready(function(){
				jQuery('#map').gMap({ address: 'Folsom Ave, San Francisco, CA',
							   panControl: true,
						   zoomControl: true,
							   zoomControlOptions: {
					style: google.maps.ZoomControlStyle.SMALL
							   },
						   mapTypeControl: true,
						   scaleControl: true,
						   streetViewControl: false,
						   overviewMapControl: true,
							   scrollwheel: true,
							   icon: {
						image: "http://www.google.com/mapfiles/marker.png",
						shadow: "http://www.google.com/mapfiles/shadow50.png",
						iconsize: [20, 34],
						shadowsize: [37, 34],
						iconanchor: [9, 34],
						shadowanchor: [19, 34]
					},
						zoom:15,
							   markers: [
							{ 'address' : 'Folsom Ave, San Francisco, CA'}
						]
							   
							   
							   }); 
				});
</script>

<script type="text/javascript">
		jQuery(function(){
			jQuery('#tweets').tweetable({
				username: 'wrapbootstrap', 
				time: true,
				rotate: false,
				speed: 4000, 
				limit: 1,
				replies: false,
				position: 'append',
				failed: "Sorry, twitter is currently unavailable for this user.",
				html5: true,
				onComplete:function(jQueryul){
					jQuery('time').timeago();
				}
			});
		});
		</script>
		<script>
			jQuery('.carousel').carousel()
		</script>
</body>
</html>