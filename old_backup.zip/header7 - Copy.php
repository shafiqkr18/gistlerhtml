<script> $(window).bind("load", function() { $(".se-pre-con2").fadeOut("slow"); }); </script>
<div class="se-pre-con2"></div>
<nav class="nav-top">
    <div class="navbar navbar-static-top" id="topnavbar"> 
      <!-- navbar-fixed-top -->
      <div class="navbar-inner" id="navbartop">
        <div class="container"> 
          <div id="main-nav" class="scroller-spy">
		  
		  
			<div class="span3 logo">
				<a href="#"><img src="images/logo-header.png"></a>
			</div>
			
			<div class="span9">
				<div class="span3 header-left">
				   <a class="topalign">&nbsp;</a>	<a href="index.php">Home</a> / <a href="#">Page Name</a>
				</div>
				
				<div class="span6 header-right">
					
					<ul id="menu3">
						
						<li><a href="#"><img src="images/question2.png"></a></li>
						<li><a href="#" class="drop">ENGLISH  &nbsp; &nbsp; </a><!-- Begin 4 columns Item -->
						 
							<div class="dropdown_1column"><!-- Begin 4 columns container -->
							 
								<div class="col_1">
									
									<ul>
										<li><a href="#">English</a></li>
										<li><a href="#">Arabic</a></li>
										<li><a href="#">French</a></li>
										<li><a href="#">Chinese</a></li>
									</ul>   
									  
								</div>
						 
							</div><!-- End 4 columns container -->
						 
						</li><!-- End 4 columns Item -->
						
						<li><a href="#" class="drop"><img src="images/aed.gif" class="map-icon"> AED &nbsp; &nbsp; </a><!-- Begin 4 columns Item -->
						 
							<div class="dropdown_2columns"><!-- Begin 4 columns container -->
							 
								<div class="col_1">
									
									<ul>
										<li><a href="#"><img src="images/aed.gif" class="map-icon"> AED</a></li>
										<li><a href="#"><img src="images/gbp.jpg" class="map-icon"> GBP</a></li>
										<li><a href="#"><img src="images/qatar.png" class="map-icon"> QTR</a></li>
										<li><a href="#"><img src="images/usd.png" class="map-icon"> USD</a></li>
									</ul>   
									  
								</div>
						 
							</div><!-- End 4 columns container -->
						 
						</li><!-- End 4 columns Item -->
					 
						<li><a href="login.php">SIGN / JOIN </a></li>
						
					 
					</ul>
					 <!--
					<a href="#"> SIGN IN &nbsp; / &nbsp; JOIN </a> <a href="#"> <img src="images/aed.gif" class="map-icon"> AED &nbsp; &nbsp; <img src="images/drop-icon.png"></a> <a href="#">ENGLISH &nbsp; &nbsp; <img src="images/drop-icon.png"></a><a href="#"><img src="images/question.png"></a>-->
				</div>
				
				<div class="clear"></div>
				
				<div class="navigation" style="display:none;">
					<ul>
						<li class="active"><a href="#">RENTALS</a></li>
						<li><a href="#">SALES</a></li>
						<li><a href="mortgage.php">MORTGAGES</a></li>
						<li><a href="#">AGENCIES</a></li>
						<li><a href="#">AGENTS</a></li>
						<li><a href="#">ADVICE</a></li>
						<li><a href="#">HOME SERVICES</a></li>
					</ul>
				</div>
				<ul id="menu">
     
					<li><a href="listing.php" class="drop">RENTALS</a><!-- Begin 4 columns Item -->
					 
						<div class="dropdown_5columns"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div><!-- End 4 columns container -->
					 
					</li><!-- End 4 columns Item -->
				 
					<li><a href="#">SALES</a>
						<div class="dropdown_5columns sales"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
					<li><a href="mortgage.php">MORTGAGES</a>
						<div class="dropdown_5columns mortgage"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
					<li><a href="#">AGENCIES</a>
						<div class="dropdown_5columns agencies"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
					<li><a href="#">AGENTS</a>
						<div class="dropdown_5columns agents"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
					<li><a href="#">ADVICE</a>
						<div class="dropdown_5columns advices"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								
								<ul>
									<li><a href="#">Buyer Checklist</a></li>
									<li><a href="#">Seller Checklist</a></li>
									<li><a href="#">Mortgage Checklist</a></li>
									<li><a href="#">Sale Transaction Fee & Charges</a></li>
									<li><a href="#">Mortgage Calculator</a></li>
									<li><a href="#">RERA Sale Forms</a></li>
									<li><a href="#">Registration Trustees</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								
								<ul>
									<li><a href="#">RERA Sale Property Registration</a></li>
									<li><a href="#">RERA Service Charge Index - Sale</a></li>
									<li><a href="#">RERA Sale Property Laws</a></li>
									<li><a href="#">Home Inspection</a></li>
									<li><a href="#">Seller Tips</a></li>
									<li><a href="#">Makani Dubai</a></li>
									<li><a href="#">Tenant Checklist</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								
								<ul>
									<li><a href="#">Landlord Checklist</a></li>
									<li><a href="#">RERA Rental Index</a></li>
									<li><a href="#">RERA Rental Increase Calculator</a></li>
									<li><a href="#">RERA Service Charge Index - Rental</a></li>
									
									<li><a href="#">RERA Rental Committee</a></li>
									<li><a href="#">RERA Rental Property Laws</a></li>
									<li><a href="#">RERA FAQs</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
					<li><a href="#">HOME SERVICES</a>
						<div class="dropdown_5columns services"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Home Maintenance</h3>
								<ul>
									<li><a href="#">Carpentry</a></li>
									<li><a href="#">Landscaping</a></li>
									<li><a href="#">Electrical</a></li>
									<li><a href="#">Painting</a></li>
									<li><a href="#">Plumbing</a></li>
									<li><a href="#">A/C Technician</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Home Decor</h3>
								<ul>
									<li><a href="#">Painting</a></li>
									<li><a href="#">Hardwood Installation</a></li>
									<li><a href="#">Carpet Installation</a></li>
									<li><a href="#">Tile Installation</a></li>
									<li><a href="#">Decorating Service</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Home Immprovement</h3>
								<ul>
									<li><a href="#">Architecture</a></li>
									<li><a href="#">General Contracting</a></li>
									<li><a href="#">Home Building</a></li>
									<li><a href="#">Engineering</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div>
					</li>
				 
				</ul>
			</div>
			
			
          </div>
        </div>
		
      </div>
  
  
  
  <script>
	$(document).ready(function()
		{	
			$(document).on('submit', '#map-filter', function()
			{
				var data = $(this).serialize();
				
				
				$.ajax({
				
				type : 'POST',
				url  : 'services_load.php',
				beforeSend: function(){
					$(".se-pre-con").fadeIn("slow");
				},
				data : data,
				success :  function(data)
						   {						
								
							$("#map_load").fadeIn(1000).show(function()
							{
								$("#map_load").html(data);
								
							});
								$(".se-pre-con").fadeOut("slow");
								
						   }
				});
				
				return false;
			});
			
			
		});
		
		
		function myFunction(){			
			document.getElementById("formsubmitbtn").click(); // Click on the checkbox
		}
		
		function selectEmirate(str){
			document.getElementById('emirate').value = str;
			myFunction();
			$("#form_reset").addClass("btnactive");
		}
		
		function changpointers(str){
			document.getElementById('ptype').value = str;
			myFunction();
			$("#form_reset").addClass("btnactive");
		}
	 
		
		function active_reset() {
			myFunction();
			$("#form_reset").addClass("btnactive");
		}
		
	</script>
	<script type="text/javascript">
	jQuery( document ).ready(function( $ ) {
	  // Code that uses jQuery's $ can follow here.
	});
      $(function() {
        var ms1 = $('#ms1').magicSuggest({
          data: ['Downtown Burj Dubai','Dubai Healthcare City','Dubai Media City','Dubai Marina','Jumeirah Lake Towers','Palm Jumeirah','Murjan','Marina Wharf 1','Royal Oceanic','Princess','Pentominium','Sparkle Tower 2','Silverene']
        });
      });
    </script>
  <script>
  $(function() {
    var availableTags = [
      "ActionScript",
      "AppleScript",
      "Asp",
      "BASIC",
      "C",
      "C++",
      "Clojure",
      "COBOL",
      "ColdFusion",
      "Erlang",
      "Fortran",
      "Groovy",
      "Haskell",
      "Java",
      "JavaScript",
      "Lisp",
      "Perl",
      "PHP",
      "Python",
      "Ruby",
      "Scala",
      "Scheme"
    ];
    $( "#tags2" ).autocomplete({
      source: availableTags
    });
  });
  </script>	
  
		<div class="bottomnav">
			<div class="container"> 
				<div class="scroller-spy">
					<div class="bottomnavigation">
						<form method="post" id="map-filter">
						<input type="hidden" name="selectedproptery" id="selectedproptery">
						<input type="hidden" name="slideremove" id="slideremove" value="">
						<ul id="menu2">
     
							<li class="menu_right"><a href="#" class="drop">Emirate &nbsp; &nbsp;  &nbsp; </a> 
     
								<div class="dropdown_1column align_right">
									<div class="col_1">
										<input type="hidden" name="emirate" id="emirate" value="">
										<ul class="simple">
											<li><a href="javascript:;" onclick="selectEmirate(1);">Dubai</a></li>
											<li><a href="javascript:;" onclick="selectEmirate(2);">Abu Dhabi</a></li>
											<li><a href="javascript:;" onclick="selectEmirate(3);">Sharjah</a></li>
											<li><a href="javascript:;" onclick="selectEmirate(4);">Others</a></li>
										</ul>   
									</div>
								</div>
								 
							</li>
							<li class="searchboxres">
								<div id="ms1" class="headsearch"></div>
								<input type="text" name="search"  placeholder="Search" id="tags2" class="headsearch" style="display:none;">
							</li>
							<script>
							$(document).ready(function() {
								$('#ui-id-1').click(function() {
									myFunction();
								});
							 });
							</script>
							
							
							<li><a href="#" class="drop">Community &nbsp; </a>
								<div class="dropdown_1column align_right">
								 
										<div class="col_1">
											
											<ul class="simple ">
												<li><input type="checkbox" id="property2" onclick="active_reset()" name="propertytype[]" value="1"> <label for="property2">Apartment (100)</label></li>
												<li><input type="checkbox" id="property3" onclick="active_reset()" name="propertytype[]" value="2"> <label for="property3">Duplex (100)</label></li>
												<li><input type="checkbox" id="property4" onclick="active_reset()" name="propertytype[]" value="3"> <label for="property4">Land Plot (100)</label></li>
												<li><input type="checkbox" id="property6" onclick="active_reset()" name="propertytype[]" value="4"> <label for="property6">Office (100)</label></li>
												<li><input type="checkbox" id="property7" onclick="active_reset()" name="propertytype[]" value="5"> <label for="property7">Penthouse (100)</label></li>
												<li><input type="checkbox" id="property8" onclick="active_reset()" name="propertytype[]" value="6"> <label for="property8">Retails Space (100)</label></li>
												
												<li><input type="checkbox" id="property9" onclick="active_reset()" name="propertytype[]" value="7"> <label for="property9">Villa/House (100)</label></li>
												<li><input type="checkbox" id="property10" onclick="active_reset()" name="propertytype[]" value="8"> <label for="property10">Townhouse (100)</label></li>
												<li><input type="checkbox" id="property11" onclick="active_reset()" name="propertytype[]" value="9"> <label for="property11">Warehouse (100)</label></li>
												<li><input type="checkbox" id="property12" onclick="active_reset()" name="propertytype[]" value="10"> <label for="property12">Buildings (100)</label></li>
												
											</ul>   
											  
										</div>
										 
								</div>
							</li>
							<li><a href="#" class="drop">All Companies &nbsp; </a>
								<div class="dropdown_1column align_right">
								 
										<div class="col_1">
											
											<ul class="simple ">
												<li><input type="checkbox" id="property2" onclick="active_reset()" name="propertytype[]" value="1"> <label for="property2">Apartment (100)</label></li>
												<li><input type="checkbox" id="property3" onclick="active_reset()" name="propertytype[]" value="2"> <label for="property3">Duplex (100)</label></li>
												<li><input type="checkbox" id="property4" onclick="active_reset()" name="propertytype[]" value="3"> <label for="property4">Land Plot (100)</label></li>
												<li><input type="checkbox" id="property6" onclick="active_reset()" name="propertytype[]" value="4"> <label for="property6">Office (100)</label></li>
												<li><input type="checkbox" id="property7" onclick="active_reset()" name="propertytype[]" value="5"> <label for="property7">Penthouse (100)</label></li>
												<li><input type="checkbox" id="property8" onclick="active_reset()" name="propertytype[]" value="6"> <label for="property8">Retails Space (100)</label></li>
												
												<li><input type="checkbox" id="property9" onclick="active_reset()" name="propertytype[]" value="7"> <label for="property9">Villa/House (100)</label></li>
												<li><input type="checkbox" id="property10" onclick="active_reset()" name="propertytype[]" value="8"> <label for="property10">Townhouse (100)</label></li>
												<li><input type="checkbox" id="property11" onclick="active_reset()" name="propertytype[]" value="9"> <label for="property11">Warehouse (100)</label></li>
												<li><input type="checkbox" id="property12" onclick="active_reset()" name="propertytype[]" value="10"> <label for="property12">Buildings (100)</label></li>
												
											</ul>   
											  
										</div>
										 
								</div>
							</li>
							<li><a href="#" class="drop">All Services &nbsp; </a>
								<div class="dropdown_1column align_right">
								 
										<div class="col_1">
											
											<ul class="simple ">
												<li><input type="checkbox" id="property2" onclick="active_reset()" name="propertytype[]" value="1"> <label for="property2">Apartment (100)</label></li>
												<li><input type="checkbox" id="property3" onclick="active_reset()" name="propertytype[]" value="2"> <label for="property3">Duplex (100)</label></li>
												<li><input type="checkbox" id="property4" onclick="active_reset()" name="propertytype[]" value="3"> <label for="property4">Land Plot (100)</label></li>
												<li><input type="checkbox" id="property6" onclick="active_reset()" name="propertytype[]" value="4"> <label for="property6">Office (100)</label></li>
												<li><input type="checkbox" id="property7" onclick="active_reset()" name="propertytype[]" value="5"> <label for="property7">Penthouse (100)</label></li>
												<li><input type="checkbox" id="property8" onclick="active_reset()" name="propertytype[]" value="6"> <label for="property8">Retails Space (100)</label></li>
												
												<li><input type="checkbox" id="property9" onclick="active_reset()" name="propertytype[]" value="7"> <label for="property9">Villa/House (100)</label></li>
												<li><input type="checkbox" id="property10" onclick="active_reset()" name="propertytype[]" value="8"> <label for="property10">Townhouse (100)</label></li>
												<li><input type="checkbox" id="property11" onclick="active_reset()" name="propertytype[]" value="9"> <label for="property11">Warehouse (100)</label></li>
												<li><input type="checkbox" id="property12" onclick="active_reset()" name="propertytype[]" value="10"> <label for="property12">Buildings (100)</label></li>
												
											</ul>   
											  
										</div>
										 
								</div>
							</li>
							
							
							<li><a href="#">100 Home Services  Companies</a></li>
						 
						</ul>
						<input type="submit" id="formsubmitbtn" style="display:none;">
						</form>
						
					</div>
				</div>
			</div>
		</div>
	  
    </div>
  
   <!-- ################-->
 <!-- END TOP MENU -->
 <!-- ################-->		
  </nav>
  <div class="se-pre-con" style="display:none;"></div>