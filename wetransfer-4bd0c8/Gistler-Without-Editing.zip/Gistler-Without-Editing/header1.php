<script> $(window).bind("load", function() { $(".se-pre-con2").fadeOut("slow"); }); </script>
<div class="se-pre-con2"></div>
<nav class="nav-top">
    <div class="navbar navbar-static-top" id="topnavbar"> 
      <!-- navbar-fixed-top -->
      <div class="navbar-inner" id="navbartop">
        <div class="container"> 
          <div id="main-nav" class="scroller-spy">
		  
            
			
			<div class="span12">
				<div class="span3 header-left">
					<a href="index.php">Home</a> / <a href="#">Page Name</a>
				</div>
				<div class="span3 logo">
					<a href="index.php"></a>
				</div>
				<div class="span6 header-right">
					
					 <ul id="menu3">
						
						<li><a href="#" class="questionmark">&nbsp;</a></li>
						<li><a href="#" class="drop">ENGLISH  &nbsp; &nbsp;</a><!-- Begin 4 columns Item -->
						 
							<div class="dropdown_1column"><!-- Begin 4 columns container -->
							 
								<div class="col_1">
									
									<ul>
										<li><a href="#">English</a></li>
										<li><a href="#">Arabic</a></li>
									</ul>   
									  
								</div>
						 
							</div><!-- End 4 columns container -->
						 
						</li><!-- End 4 columns Item -->
					 
						
						<li class="loginlink"><a href="login.php?id=0">SIGN IN </a> / <a href="login.php?id=1">JOIN </a></li>
						
					</ul>
					 
					 <!--  
					<a href="#"> SIGN IN &nbsp; / &nbsp; JOIN </a><a href="#">ENGLISH &nbsp; &nbsp; <img src="images/drop-icon.png"></a><a href="#"><img src="images/question.png"></a>-->
				</div>
			</div>
			
          </div>
        </div>
      </div>
    </div>
  
   <!-- ################-->
 <!-- END TOP MENU -->
 <!-- ################-->		
			</nav>