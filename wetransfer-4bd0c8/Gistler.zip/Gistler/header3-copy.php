<style>
.navbar-fixed-top .navbar-inner, .navbar-static-top .navbar-inner{
	padding:0px;
}
[class*="span"]{
	margin-left:23px;
}
</style>
<nav class="nav-top">
    <div class="navbar navbar-static-top" id="topnavbar"> 
      <!-- navbar-fixed-top -->
      <div class="navbar-inner" id="navbartop">
       
        
		  
			<div class="span1">
				&nbsp;
			</div>
			
			<div class="span3 logo" style="">
				<a href="#"><img src="images/logo-header.png"></a>
			</div>
			
			<div class="span8">
				<div class=" header-left" style="float:left;">
				   <a class="topalign">&nbsp;</a>	<a href="#">Home</a> / <a href="#">Search</a> / <a href="#">Results</a>
				</div>
				
				<div class="header-right"  style="float:right;">
					
					 
					<a href="#"> SIGN IN &nbsp; / &nbsp; JOIN </a> <a href="#"> <img src="images/aed.gif" class="map-icon"> AED &nbsp; &nbsp; <img src="images/drop-icon.png"></a> <a href="#">ENGLISH &nbsp; &nbsp; <img src="images/drop-icon.png"></a><a href="#"><img src="images/question.png"></a>
				</div>
				
				<div class="clear"></div>
				
				<div class="navigation" style="display:none;">
					<ul>
						<li class="active"><a href="#">RANTELS</a></li>
						<li><a href="#">SALES</a></li>
						<li><a href="#">MORTGAGES</a></li>
						<li><a href="#">AGENCIES</a></li>
						<li><a href="#">AGENTS</a></li>
						<li><a href="#">ADVICE</a></li>
						<li><a href="#">HOME SERVICES</a></li>
					</ul>
				</div>
				<ul id="menu">
     
					<li><a href="#" class="drop">RANTELS</a><!-- Begin 4 columns Item -->
					 
						<div class="dropdown_5columns"><!-- Begin 4 columns container -->
						 
							
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
									
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							<div class="col_2">
							 
								<h3>Residential Rentals</h3>
								<ul>
									<li><a href="#">All Residentials (6980)</a></li>
									<li><a href="#">Apartments/Flat for Rent (4000)</a></li>
									<li><a href="#">Villa/House for Rent (1375)</a></li>
									<li><a href="#">Townhouse for Rent (100)</a></li>
									<li><a href="#">Duplex for Rent (1300)</a></li>
									<li><a href="#">Penthouse for Rent (205)</a></li>
									<li class="linkgr"><a href="#">Upload Properties</a></li>
								</ul>   
								  
							</div>
					 
							
							 
						</div><!-- End 4 columns container -->
					 
					</li><!-- End 4 columns Item -->
				 
					<li><a href="#">SALES</a></li>
					<li><a href="#">MORTGAGES</a></li>
					<li><a href="#">AGENCIES</a></li>
					<li><a href="#">AGENTS</a></li>
					<li><a href="#">ADVICE</a></li>
					<li><a href="#">HOME SERVICES</a></li>
				 
				</ul>
			</div>
			
			
       
     
		
      </div>
	  
    </div>
  
   <!-- ################-->
 <!-- END TOP MENU -->
 <!-- ################-->		
  </nav>